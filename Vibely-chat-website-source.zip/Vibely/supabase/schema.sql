-- Vibely database schema. Run once in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Vibely member',
  avatar_url text,
  bio text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Conversation',
  type text not null check (type in ('public','direct','group')),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id,user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  content text,
  media_url text,
  media_type text,
  created_at timestamptz not null default now(),
  constraint message_has_content check (coalesce(length(content),0)>0 or media_url is not null)
);

create index if not exists messages_conversation_created_idx on public.messages(conversation_id,created_at);
create index if not exists members_user_idx on public.conversation_members(user_id);

insert into public.conversations(id,name,type)
values ('00000000-0000-0000-0000-000000000001','Public Lounge','public')
on conflict (id) do nothing;

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "profiles visible to signed in users" on public.profiles;
create policy "profiles visible to signed in users" on public.profiles for select to authenticated using (true);
drop policy if exists "users create own profile" on public.profiles;
create policy "users create own profile" on public.profiles for insert to authenticated with check (auth.uid()=id);
drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);

drop policy if exists "members can view conversations" on public.conversations;
create policy "members can view conversations" on public.conversations for select to authenticated
using (type='public' or exists(select 1 from public.conversation_members m where m.conversation_id=id and m.user_id=auth.uid()));
drop policy if exists "authenticated users create conversations" on public.conversations;
create policy "authenticated users create conversations" on public.conversations for insert to authenticated with check (auth.uid()=created_by and type in ('direct','group'));

drop policy if exists "members view memberships" on public.conversation_members;
create policy "members view memberships" on public.conversation_members for select to authenticated
using (user_id=auth.uid() or exists(select 1 from public.conversation_members mine where mine.conversation_id=conversation_id and mine.user_id=auth.uid()));
drop policy if exists "creator adds conversation members" on public.conversation_members;
create policy "creator adds conversation members" on public.conversation_members for insert to authenticated
with check (user_id=auth.uid() or exists(select 1 from public.conversations c where c.id=conversation_id and c.created_by=auth.uid()));

drop policy if exists "members read messages" on public.messages;
create policy "members read messages" on public.messages for select to authenticated
using (exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid())
 or exists(select 1 from public.conversations c where c.id=conversation_id and c.type='public'));
drop policy if exists "members send messages" on public.messages;
create policy "members send messages" on public.messages for insert to authenticated
with check (sender_id=auth.uid() and (exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid())
 or exists(select 1 from public.conversations c where c.id=conversation_id and c.type='public')));

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('chat-media','chat-media',true,10485760,array['image/jpeg','image/png','image/webp','audio/webm','audio/ogg'])
on conflict (id) do nothing;

drop policy if exists "signed-in users upload chat media" on storage.objects;
create policy "signed-in users upload chat media" on storage.objects for insert to authenticated
with check (bucket_id='chat-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "public read chat media" on storage.objects;
create policy "public read chat media" on storage.objects for select to public using (bucket_id='chat-media');

do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end $$;